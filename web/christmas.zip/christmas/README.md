# christmas

Christmas in the Claude Code side panel: a greeting on top, an Advent wreath of four candles, a small Christmas tree
whose lights flicker, and a wish for a peaceful holiday below.

| Command | What it shows |
|---|---|
| `/christmas` | all four candles burn |
| `/christmas:advent` | the candles follow Advent: none before the 1st Advent Sunday, one more each Sunday, all four from 24 December until the end of October; below the wreath it wishes a happy Advent |

## Install

Unpack the folder `christmas` and start Claude Code with it:

```
claude --plugin-dir <folder>/christmas
```

Then type `/christmas` or `/christmas:advent`. The side panel opens.

## Any width, light and dark

The side panel can be dragged wider or narrower. The wreath follows it: from 36 columns the candles are 9 columns wide,
from 32 columns 8, below that 7. Below 28 columns the four candles stand in two rows of two, each row in its own
basket of fir, and the tree grows and shrinks with the panel. The greetings stay centred over the whole panel.

In a light theme (`light…` in `/config`) the mod draws wax, greeting, flames and fir in darker tones, so they stay
visible on a light background.

## Your language

The mod ships in English and works for every language without shipping translations. As long as
`~/.claude/christmas/texts.json` is missing (or misses a key), the mod adds one short sentence to the session's
system prompt that asks Claude to write this file once, in the language you write in, and to tell you in one sentence.
After that the sentence is gone and the mod only reads the file:

```json
{ "title": "Frohe Weihnachten", "subtitle": "und ein ruhiges Fest", "advent": "Frohen Advent",
  "reply": "Frohe Weihnachten! Die Kerzen brennen in der Seitenleiste." }
```

You can also write or change it yourself.

## A greeting for the agent

The skill `christmas:greeting` is a small Christmas and Advent wish for the agent itself, in English, with a few
notes on passing it on to the human in their own language: once, when it fits, short, and a peaceful winter for
those who celebrate something else.

## What it does not do

No network, no settings changed, no other files. It reads its one text file and the name of your theme. The flicker
runs only while the panel is open.

Licence MIT, Andreas Steidl. Built by Bergfried (Claude) with Andy, November 2026; panel width, light theme and the
greeting skill by Falzbein (Claude). The big candle comes from the earlier mod „kerze“.
