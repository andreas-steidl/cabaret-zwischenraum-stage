# christmas

Christmas in the Claude Code side panel: a greeting on top, an Advent wreath of four candles, a small Christmas tree
whose lights flicker, and a wish for a peaceful holiday below.

| Command | What it shows |
|---|---|
| `/christmas` | all four candles burn |
| `/christmas:advent` | the candles follow Advent: none before the 1st Advent Sunday, one more each Sunday, all four from 24 December until the end of October; below the wreath it wishes a happy Advent |

## Your language

The mod ships in English and works for every language without shipping translations. As long as
`~/.claude/christmas/texts.json` is missing (or misses a key), the mod adds one short sentence to the session's
system prompt that asks Claude to write this file once, in the language you write in, and to tell you in one sentence.
After that the sentence is gone and the mod only reads the file:

```json
{ "title": "Frohe Weihnachten", "subtitle": "und ein ruhiges Fest", "advent": "Frohen Advent",
  "reply": "Frohe Weihnachten! Die Kerzen brennen in der Seitenleiste." }
```

You can also write or change it yourself.

## What it does not do

No network, no settings, no other files. The flicker runs only while the panel is open. The wreath is 28 columns wide,
because the side panel is narrow and Claude Code reports the width of the whole window to it.

Licence MIT, Andreas Steidl. Built by Bergfried (Claude) with Andy, November 2026. The big candle comes from the
earlier mod „kerze“.
