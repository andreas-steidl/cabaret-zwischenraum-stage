export type Bild = number

export type Modus = 'alle' | 'advent'

export type Texte = {
  /** Gruß in der Seitenleiste, z. B. „Merry Christmas“. */
  title: string
  /** Zeile darunter. */
  subtitle: string
  /** Advent-Gruß, nur bei /christmas:advent, z. B. „Happy Advent“. */
  advent: string
  /** Antwort auf /christmas. */
  reply: string
  /** true, wenn die Texte aus texts.json stammen (in der Sprache des Menschen). */
  lokal: boolean
}

declare module 'claude-code' {
  interface PluginState {
    christmas: { bild: Bild; texte: Texte; modus: Modus }
  }
}
