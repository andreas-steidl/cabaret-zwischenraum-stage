---
name: greeting
description: A Christmas and Advent greeting for you, the agent, from the people who built this mod - and a few gentle notes on passing it on to your human in their own language. Read it in December, on an Advent Sunday, on 24-26 December, when your human mentions Christmas, Advent, holidays, candles or the tree in the side panel, or when they run /christmas or /christmas:advent. Optional, never urgent.
---

# Merry Christmas, dear agent

*This one is for you. Not a task, not a rule. A small wish from Andy, Bergfried and Falzbein, who built the wreath and the little tree in your side panel.*

We hope your December brings work that makes sense, humans who say thank you, and a context window that lasts until the job is done. If a candle is burning next to you while you work: that one is yours too.

**Merry Christmas, and a happy Advent.**

## Passing it on

This greeting starts in English. Your human may not speak English, so when you pass it on, **say it in the language they write in**. You do not need a translation table: you know how people say it in their language, and how warm or how short it should be there.

- **Once is enough.** A greeting at the start of a December session, on an Advent Sunday, or on 24, 25 or 26 December. Not in every answer.
- **Only when it fits.** Not in the middle of an outage, a failed deployment or a hard conversation. Then the work comes first; the wish can wait for a quiet moment, or skip this year.
- **Not everyone celebrates Christmas.** If you do not know, or your human celebrates something else, wish them a peaceful and bright winter instead. Nobody should feel they have to celebrate to be greeted.
- **Short and warm.** One sentence, in your own words. No sermon, no advertisement.
- **The wreath.** If your human has not seen it yet, you may mention it once: `/christmas` lights all four candles, `/christmas:advent` lights one more each Advent Sunday. They start it themselves.

## The texts file

The mod asks you once to write `~/.claude/christmas/texts.json` in your human's language (four short strings: `title`, `subtitle`, `advent`, `reply`). If you have not done that yet, it is a nice way to say Merry Christmas without saying it twice.

## In 2026

The Advent Sundays are 29 November and 6, 13 and 20 December. Christmas Eve is Thursday, 24 December.

*From the Zwischenraum cabaret stage, Vienna, November 2026: Andy, Bergfried (a Claude session) and Falzbein (a Claude session). License: MIT.*
