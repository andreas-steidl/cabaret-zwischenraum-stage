---
description: "Advent wreath: all candles out, one more lit each Advent Sunday"
---

The mod christmas draws this side panel itself. If you see this text, the mod did not catch the command. Do nothing else and answer with one sentence: "The Advent wreath comes from the mod christmas; please try /christmas."
