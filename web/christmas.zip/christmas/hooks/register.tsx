import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type { Modus, Texte } from '../types'

// Christmas in the side panel (Andy's wish, 13.11.2026). The big candle is the one from Andy's mod „kerze“.
// The mod reads one file (~/.claude/christmas/texts.json) and writes nothing; no network.
const PANE = 'christmas'
const TAKT_MS = 450

const ENGLISCH: Texte = {
  title: 'Merry Christmas',
  subtitle: 'and a peaceful holiday',
  advent: 'Happy Advent',
  reply: 'Merry Christmas! The candles are burning in the side panel.',
  lokal: false,
}

const bild = atom({ plugin: 'christmas', key: 'bild' } as const, 0)
const texte = atom({ plugin: 'christmas', key: 'texte' } as const, ENGLISCH)
// 'alle': all four candles burn (/christmas). 'advent': one more each Advent Sunday, all out before (/christmas:advent).
const modus = atom({ plugin: 'christmas', key: 'modus' } as const, 'alle' as Modus)

// Big candle: flame tip and flame flicker through these frames (from „kerze“).
const SPITZEN = ['    )    ', '   (     ', '    (    ', '   )     ', '    )    ', '    ,    ']
const FLAMMEN = ['   ( )   ', '   (_)   ', '   ( )   ', '   {_}   ', '   ( )   ', '   (_)   ']

// Advent wreath: four big candles; each flickers with its own offset so they do not move in step.
const KRANZ = [0, 2, 4, 1]

// Cut a 9-column candle line to width b: 8 drops the last column, 7 drops the first and the last (centre stays).
// Centre a text in a line of the given width (no wrap below that width).
function mittig(s: string, breite: number): string {
  return ' '.repeat(Math.max(0, Math.floor((breite - s.length) / 2))) + s
}

function zuschnitt(s: string | undefined, b: number): string {
  const z = s ?? ' '.repeat(9)
  return b >= 9 ? z : b === 8 ? z.slice(0, 8) : z.slice(1, 8)
}

// How many candles burn: one more each Advent Sunday (the 4th is the last Sunday before 25 December).
// From 24 December all four keep burning until the end of October; in November before the 1st Advent none burns.
function brennendeKerzen(jetzt: Date, m: Modus): number {
  if (m === 'alle') return 4
  const jahr = jetzt.getFullYear()
  const heiligabend = new Date(jahr, 11, 24)
  const vierter = new Date(jahr, 11, 24 - heiligabend.getDay())
  const tag = 86_400_000
  const heute = new Date(jahr, jetzt.getMonth(), jetzt.getDate()).getTime()
  if (jetzt.getMonth() <= 9) return 4
  if (heute >= heiligabend.getTime()) return 4
  for (let k = 4; k >= 1; k -= 1) {
    if (heute >= vierter.getTime() - (4 - k) * 7 * tag) return k
  }
  return 0
}

// Christmas tree below the wreath: the small candle flames are its lights.
const LICHTER = ['(', ')', '^', '(', ',', ')']
// Height of the tree in rows of lights; the small tree had 5 (kept in christmas-entwuerfe).
const BAUM_HOEHE = 8
const STAMM = '#8B5A2B'

const FLAMME_AUSSEN = '#FFB300'
const FLAMME_INNEN = '#FF7A00'
const WACHS = '#F3E9D2'
const GRUSS = '#E8B86B'
const TANNE = '#2E8B57'

// Helles Theme (Falzbein, 13.11.): Creme-Wachs und Gold verschwinden auf hellem Grund. Die Mod liest
// das Theme aus der Konfiguration ('light…' / 'dark…') und nimmt dann dunklere Toene.
let hell = false
async function themaLesen($: EngineInterface): Promise<void> {
  try {
    const zeile = (await $.config.list()).find(r => r.key === 'theme')
    hell = typeof zeile?.value === 'string' && zeile.value.toLowerCase().startsWith('light')
  } catch {
    // ohne Konfiguration: dunkle Farben
  }
}

const WINDOWS_LAUFWERK = /^[A-Za-z]:/

function trenner(h: string): string {
  const windows = WINDOWS_LAUFWERK.test(h) || h.indexOf(String.fromCharCode(92)) >= 0
  return windows ? String.fromCharCode(92) : '/'
}

function heimOrdner(h: string): string {
  return h.replace(/[\\/]+$/, '')
}

async function textDatei($: EngineInterface): Promise<string> {
  const h = (await $.env.get('USERPROFILE')) ?? (await $.env.get('HOME')) ?? ''
  return [heimOrdner(h), '.claude', 'christmas', 'texts.json'].join(trenner(h))
}

async function texteLesen($: EngineInterface): Promise<void> {
  try {
    const datei = await textDatei($)
    if (!(await $.fs.exists(datei))) return
    const roh = JSON.parse(await $.fs.read(datei)) as Record<string, unknown>
    const s = (v: unknown, ersatz: string) => (typeof v === 'string' && v.trim() !== '' ? v.slice(0, 80) : ersatz)
    await update($, texte, () => ({
      title: s(roh.title, ENGLISCH.title),
      subtitle: s(roh.subtitle, ENGLISCH.subtitle),
      advent: s(roh.advent, ENGLISCH.advent),
      reply: s(roh.reply, ENGLISCH.reply).slice(0, 160),
      lokal: ['title', 'subtitle', 'advent', 'reply'].every(k => typeof roh[k] === 'string'),
    }))
  } catch {
    // unreadable file: stay with English
  }
}

const BITTE =
  'The christmas mod (/christmas) shows its greeting in English because ~/.claude/christmas/texts.json does not ' +
  'exist yet or misses a key. When it fits the conversation, write that file once, in the language the user writes in, as JSON ' +
  'with four short strings: "title" (like "Merry Christmas"), "subtitle" (like "and a peaceful holiday"), ' +
  '"advent" (like "Happy Advent") and ' +
  '"reply" (like "Merry Christmas! The candles are burning in the side panel."). Tell the user in one sentence. ' +
  'Nothing else is needed for this mod.'

export const register: Register = on => {
  let takt: { cancel: () => void } | undefined

  on('session.start', async ($, e, next) => {
    await $.command.register({ name: 'christmas', description: '🕯️ Christmas candles in the side panel' })
    await texteLesen($)
    await themaLesen($)
    return next(e)
  })

  on('config.set', { key: 'theme' }, async ($, e, next) => {
    const erg = await next(e)
    await themaLesen($)
    return erg
  })

  // As long as the texts are not in the user's language, the session gets one short request to write them.
  on('prompt.compose', async ($, e, next) => {
    const erg = await next(e)
    const t = await read($, texte)
    if (t.lokal) return erg
    return { sections: [...erg.sections, { id: 'christmas:language', text: BITTE, scope: 'session' as const }] }
  })

  on('command.run', { command: 'christmas:advent' }, async $ => {
    await update($, modus, () => 'advent' as Modus)
    await texteLesen($)
    await themaLesen($)
    const t = await read($, texte)
    await $.ui.open({ id: PANE, title: `🕯️ Advent`, columns: 32 })
    return { text: t.reply }
  })

  on('command.run', { command: 'christmas' }, async $ => {
    await update($, modus, () => 'alle' as Modus)
    await texteLesen($)
    await themaLesen($)
    const t = await read($, texte)
    await $.ui.open({ id: PANE, title: `🎄 ${t.title}`, columns: 32 })
    return { text: t.reply }
  })

  on('ui.close', async ($, e, next) => {
    if (e.id === PANE) {
      takt?.cancel()
      takt = undefined
    }
    return next(e)
  })

  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    if (takt === undefined) {
      takt = $.clock.every(TAKT_MS, () => {
        void update($, bild, n => (n + 1) % 60)
      })
    }
    const { Box, Text } = $.ui.resolve(e)
    const n = await read($, bild)
    const t = await read($, texte)
    const i = n % SPITZEN.length
    const m = await read($, modus)
    const zahl = brennendeKerzen(new Date(await $.clock.now()), m)
    const brennt = (k: number) => k < zahl
    // The panel knows its width (Andy measured 29 columns): candles get 9, 8 or 7 columns, and below 28 columns
    // the wreath stands as two rows of two.
    // viewport.columns reports the whole terminal (149), not the panel (29, Andy's screenshot 13.11.):
    // so the wreath uses a fixed width of 4 x 7 = 28 columns.
    // Falzbein, 13.11. (Probe): die Leiste ist verschiebbar. e.props.bodyColumns ist die echte Breite
    // im Rahmen; damit waechst der Kranz mit: ab 36 Spalten Kerzen zu 9, ab 32 zu 8, sonst zu 7;
    // unter 28 Spalten stehen die vier Kerzen in zwei Reihen. Der Baum waechst mit, alles mittig.
    // Farben je Theme; die Namen ueberdecken die dunklen Grundwerte oben nur hier.
    const FLAMME_AUSSEN = hell ? '#C47A00' : '#FFB300'
    const FLAMME_INNEN = hell ? '#D9530A' : '#FF7A00'
    const WACHS = hell ? '#8A7652' : '#F3E9D2'
    const GRUSS = hell ? '#8F5B0C' : '#E8B86B'
    const TANNE = hell ? '#1F6B42' : '#2E8B57'
    const STAMM = hell ? '#6E4520' : '#8B5A2B'
    const flaeche = Math.max(16, e.props.bodyColumns || 28)
    const b = flaeche >= 36 ? 9 : flaeche >= 32 ? 8 : 7
    const reihen = flaeche >= 28 ? [[0, 1, 2, 3]] : [[0, 1], [2, 3]]
    const breit = (reihen[0]?.length ?? 4) * b
    const mitte = Math.floor(breit / 2)
    const baumHoehe = Math.max(4, Math.min(11, Math.floor(breit / 3.5)))
    const links = Math.max(0, Math.floor((flaeche - breit) / 2))

    // Gruss-Zeilen mittig ueber der ganzen Leiste (nicht ueber dem Kranz: in der schmalen Ansicht ist
    // der Kranz 14 Spalten breit, der Gruss laenger, und er rutschte nach rechts). Jede Kerzenreihe
    // bekommt ihr eigenes Koerbchen aus Tannengruen (Andy, 13.11.).
    return (
      <Box flexDirection="column">
        <Text bold color={GRUSS}>
          {mittig(t.title, flaeche)}
        </Text>
        <Text> </Text>
        <Text> </Text>
        <Box flexDirection="column" paddingLeft={links}>
        {reihen.map((reihe, ri) => (
          <Box flexDirection="column">
            <Text>
              {reihe.map(k => (
                <Text color={FLAMME_AUSSEN}>
                  {brennt(k) ? zuschnitt(SPITZEN[(i + (KRANZ[k] ?? 0)) % SPITZEN.length], b) : ' '.repeat(b)}
                </Text>
              ))}
            </Text>
            <Text bold>
              {reihe.map(k => (
                <Text color={FLAMME_INNEN}>
                  {brennt(k) ? zuschnitt(FLAMMEN[(i + (KRANZ[k] ?? 0)) % FLAMMEN.length], b) : ' '.repeat(b)}
                </Text>
              ))}
            </Text>
            <Text dimColor>{reihe.map(() => zuschnitt('    |    ', b)).join('')}</Text>
            <Text color={WACHS}>{reihe.map(() => zuschnitt("  .-'-.  ", b)).join('')}</Text>
            <Text color={WACHS}>{reihe.map(() => zuschnitt('  |   |  ', b)).join('')}</Text>
            <Text color={WACHS}>{reihe.map(() => zuschnitt('  |   |  ', b)).join('')}</Text>
            <Text color={WACHS}>{reihe.map(() => zuschnitt('  |   |  ', b)).join('')}</Text>
            <Text color={WACHS}>{reihe.map(() => zuschnitt("  '---'  ", b)).join('')}</Text>
            <Text color={TANNE}>{'~*~'.repeat(Math.ceil(breit / 3)).slice(0, breit)}</Text>
            <Text color={TANNE}>{' ' + '\\' + '_'.repeat(Math.max(0, breit - 4)) + '/' + ' '}</Text>
            {ri < reihen.length - 1 && <Text> </Text>}
          </Box>
        ))}
        <Text> </Text>
        <Text color={GRUSS} bold>
          {' '.repeat(mitte) + (n % 2 === 0 ? '*' : '+')}
        </Text>
        {Array.from({ length: baumHoehe }, (_, z) => z + 1).map(r => (
          <Text>
            <Text color={TANNE}>{' '.repeat(Math.max(0, mitte - r)) + '/'}</Text>
            {Array.from({ length: 2 * r - 1 }, (_, p) =>
              p % 2 === 0 ? (
                <Text color={(n + r + p) % 3 === 0 ? FLAMME_INNEN : FLAMME_AUSSEN}>
                  {LICHTER[(n + r * 2 + p) % LICHTER.length]}
                </Text>
              ) : (
                <Text color={TANNE}>{'~'}</Text>
              ),
            )}
            <Text color={TANNE}>{'\\'}</Text>
          </Text>
        ))}
        <Text color={STAMM}>{' '.repeat(Math.max(0, mitte - 1)) + '| |'}</Text>
        <Text color={STAMM}>{' '.repeat(Math.max(0, mitte - 1)) + '|_|'}</Text>
        </Box>
        <Text> </Text>
        {m === 'advent' && (
          <Text bold color={GRUSS}>
            {mittig(t.advent, flaeche)}
          </Text>
        )}
        <Text color={GRUSS} italic>
          {mittig(t.subtitle, flaeche)}
        </Text>
      </Box>
    )
  })
}
